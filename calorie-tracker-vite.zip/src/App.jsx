import React from 'react';
export default function App() {
  return <h1>Calorie Tracker</h1>;
}
