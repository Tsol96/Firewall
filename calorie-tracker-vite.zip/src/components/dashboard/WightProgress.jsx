// WightProgress component code here
